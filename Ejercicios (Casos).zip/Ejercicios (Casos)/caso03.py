""" Desarrolle un programa que genere el importe de ventas en forma aleatoria para 15
empleados de una tienda con montos comprendidos entre 1250 a 10000 y muestre lo
siguiente:
✓ El importe generado aleatoriamente
✓ La suma total de los 15 importes
✓ La cantidad de importes comprendidos entre S/. 1250 a S/ 3000
✓ La cantidad de importes comprendidos entre S/. 3001 a S/ 5000
✓ La cantidad de importes comprendidos entre S/. 5001 a S/ 6999
✓ La cantidad de importes comprendidos entre S/. 7000 a S/ 10000"""
import random
suma_total = 0
cantidad_1250_3000 = 0
cantidad_3001_5000 = 0
cantidad_5001_6999 = 0
cantidad_7000_10000 = 0

for _ in range(15):
    importe = random.randint(1250, 10000)
    suma_total += importe

    if 1250 <= importe <= 3000:
        cantidad_1250_3000 += 1
    elif 3001 <= importe <= 5000:
        cantidad_3001_5000 += 1
    elif 5001 <= importe <= 6999:
        cantidad_5001_6999 += 1
    else:
        cantidad_7000_10000 += 1

print(f"Importe generado aleatoriamente: {importe}")
print(f"Suma total de los 15 importes: {suma_total}")
print(f"Cantidad de importes entre S/. 1250 a S/. 3000: {cantidad_1250_3000}")
print(f"Cantidad de importes entre S/. 3001 a S/. 5000: {cantidad_3001_5000}")
print(f"Cantidad de importes entre S/. 5001 a S/. 6999: {cantidad_5001_6999}")
print(f"Cantidad de importes entre S/. 7000 a S/. 10000: {cantidad_7000_10000}")