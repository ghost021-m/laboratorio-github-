""" Desarrolle un programa que muestre los múltiplos de 3 a partir del 3 hasta el número
que el usuario indique en una caja de texto """

numero = int(input("Ingrese un número: "))
for i in range(3, numero+1, 3): #Inicia en 3 hasta el número ingresado. Incremento en 3 
    print(f"{i}")

