for i, j, k in zip(range(11, 0, -2), range(2, 18, 3), range(7, 43, 7)):
    print(f"{i}\t{j}\t{k}")
    