""" Funciones """
# Funcion con retorno de valor


def suma():
    a = 3 
    b = 5
    s = a + b
    return s # Retorna el resultado


res = suma()
print(f"Suma: {res}")  


def resta():
    """ Funcion que retorna la resta de 2 numeros """
    a = 3 # a, b, s son "variables locales"
    b = 5
    s = a - b
    return s # Retorna el resultado 


res_suma = suma() # Llamamos a la funcion 
res_resta = resta()
print(f"Suma: {res_suma}")
print(f"Resta: {res_resta}")
