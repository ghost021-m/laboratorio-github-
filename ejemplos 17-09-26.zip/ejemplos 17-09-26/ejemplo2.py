""" Funciones """
# Funcion SIN retorno de valor SIN PARAMETROS


def resta(): # resta o suma 
    """ Funcion... """
    global s 
    a = 1230
    b = 554 
    s = a - b


resta() # Llamamos a la función (puede ser resta o suma segun la "def")
print(f"resta: {s}")
    