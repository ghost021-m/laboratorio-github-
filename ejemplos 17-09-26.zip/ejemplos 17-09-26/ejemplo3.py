""" Funciones """
# Funcion con retorno de valor CON PARAMETROS


def suma(a, b): # Funcion con 2 parametros 
    """ Funcion que RECIBE 2 valores """
    s = a + b
    return s # Retorna el resultado




# Funcion que recibe un numero y retorna si es par o impar
def par_impar(num):
    if num % 2 == 0:
        mensaje = "par"
    else:
        mensaje = "impar"
    return mensaje
       




# res_suma y res_resta son "variables globales"
res_suma = suma(123, 103) # Llamamos a la funcion
menor = min(1239, 1345) # Max(num mayor) Min(num menor)

condicion = par_impar(99)   


print(f"La suma es: {res_suma}")
print(f"El numero menor es: {menor}")
print(f"EL numero es: {condicion}")

    