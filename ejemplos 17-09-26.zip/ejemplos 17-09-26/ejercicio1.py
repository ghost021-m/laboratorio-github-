""" Ejercicio 1: Caso empresa de computadora """

def leer_marca():
    """ Funcion para elegir la marca """
    print("1. Dell")
    print("2. HP")
    print("3. Apple")
    print("4. Asus")
    
    """Validamos la marca"""
    while True:
        marca = int(input("Eliga la marca: "))
        return marca


def leer_cantidad():
    """ Funcion para leer la cantidad """
    while True:
        try:
            cantidad = int(input("Cantidad: "))
            if cantidad < 0:
                print("El numero debe ser positivo!!")
                continue # Obliga a repetir el While
            return cantidad
        except ValueError:
            print("Error!!! Ingrese un numero positivo")


# Funcion que calcula el importe de la compra

# Si la variable proviene de otra funcion, entonces
# se define como PARAMETRO
def importe_compra(marca, cantidad):  # Usar PARAMETRO para la variable CANTIDAD, no es recomendable usar el GLOBAL (consumo de mucha memoria)
    """ Funcion.... """
    match marca:
        case 1:
            precio = 11000
        case 2:
            precio = 9000
        case 3:
            precio = 13000
        case 4: 
            precio = 12500
            
    imp_compra = cantidad * precio
    return imp_compra


# Funcion que calcula el importe de descuento
def importe_descuento(cantidad, importe_compra):
    """ Funcion... """
    if cantidad <= 3:
        imp_desc = 0.035 * importe_compra
    elif cantidad < 6:
        imp_desc = 0.05 * importe_compra
    elif cantidad < 9: 
        imp_desc = 0.065 * importe_compra
    else: 
        imp_desc = 0.08 * importe_compra
    return importe_descuento



mar = leer_marca()
can = leer_cantidad()
i_c = importe_compra(mar, can)
i_d = importe_descuento(can, i_c)

print(f"Importe de compra: {i_c}")
print(f"Improte de descuento: {i_d}")



