"""Desarrolle un programa que permita ingresar un número entero e imprima los divisores
de dicho valor y la cantidad de divisores hallados.""" 
can_divisores = 0
numero = int(input("Ingrese numero "))
for div in range(1, numero+1):
    if numero % div == 0: # Si el residuo es 0, entonces es divisor
        print(f"{div}")
        # Contamos la cantidad de divisores
        can_divisores = can_divisores + 1 
print(f"Numero de divisores: {can_divisores}")