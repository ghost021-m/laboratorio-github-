""" Desarrolle un programa que genere aleatoriamente las edades de 30 personas y
calcule la edad promedio, la cantidad personas mayores de edad y la cantidad de
personas menores de edad """
import random 
can_mayores = 0
can_menores = 0
for i in range(30):
    # Generar la edad aleatoria 
    edad = random.randint(1, 100) # Genera un numero aleatorio entre 1 y 100
    # Generar la candidad e mayores y menores de edad 
    if edad >= 18: 
        can_mayores = can_mayores +1
    else: 
        can_menores = can_menores +1
# Imprimir los resultados
print(f"Cantidad de personas mayores de edad: {can_mayores}")
print(f"Cantidad de personas menores de edad: {can_menores}")
    